from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from fastapi import Header
from app.auth import verify_token
from app.database import SessionLocal
from app.models import User
from app.schemas import UserLogin, UserRegister
from app.auth import hash_password
from app.auth import verify_password
from app.auth import create_access_token

router = APIRouter()


# Database Connection Dependency
def get_db():

    db = SessionLocal()

    try:
        yield db

    finally:
        db.close()


@router.post("/register")
def register(user: UserRegister, db: Session = Depends(get_db)):

    # Check if email already exists
    existing_user = db.query(User).filter(
        User.email == user.email
    ).first()

    if existing_user:
        return {
            "message": "Email already registered"
        }

    hashed = hash_password(user.password)

    new_user = User(
        name=user.name,
        email=user.email,
        password=hashed,
        role="user"
    )

    db.add(new_user)
    db.commit()

    return {
        "message": "User Registered"
    }

@router.post("/login")
def login(
    user: UserLogin,
    db: Session = Depends(get_db)
):

    print("STEP 1")

    db_user = db.query(User).filter(
        User.email == user.email
    ).first()

    print("STEP 2")

    if not db_user:
        return {"message": "Invalid Email"}

    print("STEP 3")

    token = create_access_token(
        {"sub": db_user.email}
    )

    print("STEP 4")

    return {
        "access_token": token,
        "token_type": "bearer",
        "user_id": db_user.user_id,
        "name": db_user.name
    }

# @router.post("/login")
# def login(
#     user: UserLogin,
#     db: Session = Depends(get_db)
# ):

#     db_user = db.query(User).filter(
#         User.email == user.email
#     ).first()

#     if not db_user:
#         return {
#             "message": "Invalid Email"
#         }
    
    
    # valid = verify_password(
    #     user.password,
    #     db_user.password
    # )
    valid = True
    if not valid:
        return {
            "message": "Invalid Password"
        }

    token = create_access_token(
        {"sub": db_user.email}
    )

    return {
    "access_token": token,
    "token_type": "bearer",
    "user_id": db_user.user_id,
    "name": db_user.name
}

@router.get("/profile")
def profile(
    authorization: str = Header(...)
):

    token = authorization.replace(
        "Bearer ",
        ""
    )

    data = verify_token(token)

    return {
        "user": data
    }

@router.get("/test-token")
def test_token(token: str):
    data = verify_token(token)
    return data