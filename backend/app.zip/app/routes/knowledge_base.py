from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from fastapi import UploadFile, File
from app.database import SessionLocal
from app.models import KnowledgeBase
from app.schemas import KnowledgeBaseCreate

router = APIRouter(
    prefix="/knowledge-base",
    tags=["Knowledge Base"]
)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/")
def create_document(
    document: KnowledgeBaseCreate,
    db: Session = Depends(get_db)
):
    new_document = KnowledgeBase(
        file_name=document.file_name,
        file_path=document.file_path
    )

    db.add(new_document)
    db.commit()

    return {
        "message": "Document Added Successfully"
    }


@router.get("/")
def get_documents(
    db: Session = Depends(get_db)
):
    return db.query(KnowledgeBase).all()

@router.post("/upload")
async def upload_pdf(file: UploadFile = File(...)):
    path = f"data/{file.filename}"

    with open(path, "wb") as buffer:
        buffer.write(await file.read())

    return {
        "message": "PDF uploaded",
        "file": file.filename
    }

# @router.get("/search")
# def search_question(
#     q: str,
#     db: Session = Depends(get_db)
# ):

#     result = db.query(
#         KnowledgeBase
#     ).filter(
#         KnowledgeBase.question.ilike(
#             f"%{q}%"
#         )
#     ).first()

#     if result:
#         return result

#     return {
#         "answer": "No answer found"
#     }