from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.models import Feedback
from app.schemas import FeedbackCreate

router = APIRouter(
    prefix="/feedback",
    tags=["Feedback"]
)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/")
def create_feedback(
    feedback: FeedbackCreate,
    db: Session = Depends(get_db)
):

    new_feedback = Feedback(
        user_id=feedback.user_id,
        content=feedback.content,
        rating=feedback.rating
    )

    db.add(new_feedback)
    db.commit()
    db.refresh(new_feedback)

    return {
        "message": "Feedback submitted successfully",
        "data": new_feedback
    }


@router.get("/")
def get_feedbacks(
    db: Session = Depends(get_db)
):
    return db.query(Feedback).all()