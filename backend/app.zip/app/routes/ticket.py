from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.schemas import TicketCreate, ChatRequest
from app.rag.query import search_documents
from app.database import SessionLocal
from app.models import Ticket, TicketReply
from app.schemas import TicketCreate, ChatRequest
from app.classifier import classify_ticket
from app.priority import predict_priority
from app.rag.query import search_documents

router = APIRouter(
    prefix="/tickets",
    tags=["Tickets"]
)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("/")
def create_ticket(
    ticket: TicketCreate,
    db: Session = Depends(get_db)
):  
    request_type = classify_ticket(
    ticket.description
    )

    priority = predict_priority(
    ticket.description
    )

    new_ticket = Ticket(
        user_id=ticket.user_id,
        subject=ticket.subject,
        description=ticket.description,
        request_type=request_type,
        priority=priority
    )

    db.add(new_ticket)
    db.commit()
    db.refresh(new_ticket)

    return {
        "message": "Ticket Created Successfully",
        "data": new_ticket
    }


@router.get("/")
def get_tickets(
    db: Session = Depends(get_db)
):
    return db.query(Ticket).all()

# @router.post("/tickets")
# def create_ticket(ticket: TicketCreate):

#     return {
#         "message": "Ticket Created Successfully"
#     }

from app.faq_search import search_faq

@router.post("/chat")
def chat(request: ChatRequest):

    faq_result = search_faq(
        request.question
    )

    if faq_result:
        return faq_result

    rag_result = search_documents(
        request.question
    )

    try:

        docs = rag_result["documents"][0]

        if docs:

            return {
                "question": request.question,
                "answer": docs[0]
            }

    except Exception as e:

        print(e)

    return {
        "question": request.question,
        "answer":
        "Sorry, I couldn't find a relevant answer in the enterprise knowledge base."
    }
    
@router.get("/{ticket_id}")
def get_ticket(
    ticket_id: int,
    db: Session = Depends(get_db)
):

    ticket = db.query(Ticket).filter(
        Ticket.ticket_id == ticket_id
    ).first()

    if not ticket:
        return {
            "message": "Ticket not found"
        }

    return ticket

@router.get("/user/{user_id}")
def get_user_tickets(
    user_id: int,
    db: Session = Depends(get_db)
):

    tickets = db.query(Ticket).filter(
        Ticket.user_id == user_id
    ).all()

    return tickets

@router.post("/{ticket_id}/reply")
def add_reply(
    ticket_id: int,
    agent_name: str,
    message: str,
    db: Session = Depends(get_db)
):

    reply = TicketReply(
        ticket_id=ticket_id,
        agent_name=agent_name,
        message=message
    )

    db.add(reply)
    db.commit()

    return {"message": "Reply Added"}

@router.get("/{ticket_id}/replies")
def get_replies(
    ticket_id: int,
    db: Session = Depends(get_db)
):
    return db.query(TicketReply).filter(
        TicketReply.ticket_id == ticket_id
    ).all()