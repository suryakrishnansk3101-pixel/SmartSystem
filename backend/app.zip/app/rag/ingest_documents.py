from app.rag.load_documents import load_documents
from app.rag.vector_store import collection

documents = load_documents()

chunks = []

for doc in documents:

    if doc.page_content.strip():

        chunks.append(
            doc.page_content
        )

print("Chunks:", len(chunks))

if len(chunks) > 0:

    collection.add(
        documents=chunks,
        ids=[str(i) for i in range(len(chunks))]
    )

    print("Documents stored successfully")

else:

    print("No documents found")