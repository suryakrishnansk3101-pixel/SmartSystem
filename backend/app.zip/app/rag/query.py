from app.rag.vector_store import collection

def search_documents(question):

    results = collection.query(
        query_texts=[question],
        n_results=3
    )

    return results