from langchain_community.document_loaders import (
    PyPDFLoader,
    Docx2txtLoader,
    UnstructuredExcelLoader
)
import os


def load_documents():

    all_docs = []

    folders = [
        "data/pdf",
        "data/text"
    ]

    for data_folder in folders:

        if not os.path.exists(data_folder):
            continue

        print("Scanning:", data_folder)

        for file in os.listdir(data_folder):

            file_path = os.path.join(
                data_folder,
                file
            )

            print("Loading:", file_path)

            if file.endswith(".pdf"):

                loader = PyPDFLoader(
                    file_path
                )

                all_docs.extend(
                    loader.load()
                )

            elif file.endswith(".docx"):

                loader = Docx2txtLoader(
                    file_path
                )

                all_docs.extend(
                    loader.load()
                )

            elif file.endswith(".xlsx"):

                loader = UnstructuredExcelLoader(
                    file_path
                )

                all_docs.extend(
                    loader.load()
                )

    print("Total documents:", len(all_docs))

    return all_docs